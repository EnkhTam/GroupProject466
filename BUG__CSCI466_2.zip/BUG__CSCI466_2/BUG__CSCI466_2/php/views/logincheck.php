<!DOCTYPE html>
<html>
<head>
<title>You donked up</title>
<link rel= "stylesheet" type = "text/css" href = "../../css/base/custom.css">
<link rel = "icon" href="http://students.cs.niu.edu/~z1865285/bug/media/img/base/cursor.gif">

<style>
    h2 {
        color: lightgrey;
        font-weight: bold;
    }
</style>
</head>
<body>
<iframe width="0%" height="0" scrolling="no" frameborder="no" allow="autoplay, loop" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/292015932&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"></iframe>
<?php
include('../includes/config.php');
setcookie('username', $_POST['username']);
setcookie('pass', password_hash($_POST['password'], PASSWORD_DEFAULT, array('cost'=>12)));
$user = $_POST['username'];
$pass = $_POST['password'];
mysqli_select_db($conn, 'z1865285');
//check if user in database
//$checkuser = mysqli_query($conn, "SELECT * FROM user WHERE user_name = '$user' ");
$sql = "SELECT COUNT(*) AS xx FROM user WHERE user_name = ?";
$checku = $pdo->prepare($sql);
$checku->execute([$user]);
$checkr = $checku->fetch();
//number of rows function, if produces one row then name is there
//password and confirm password on registration, check if those match
//if (mysqli_num_rows($checkuser) == true){
if($checkr['xx'] > 0)
{
	$checkuser = mysqli_query($conn, "SELECT * FROM user WHERE user_name = '$user' ");
	if($row = mysqli_fetch_array($checkuser))
	{
		//if ($row['pass_word'] == $pass){
		if(password_verify($pass, $row['pass_word']))
		{
			$namee = $row['first_name'];
			setcookie('firstname',$namee);
			//sets up the cookies for the next few pages
			header("Location: ../views/main.php");
		}
		else
		{
			//error message is released
			$message = "Incorrect Password";
			echo "<h2>Incorrect password</h2><br>
			<a href = '../../index.php'>Go Back</a>";
		}
	}
}
else{
	//gives an error if the user cannot be found
	$message = "User does not exist, please register if you have not.";
	echo "<h2>$message</h2><br>
	<a href = '../../index.php'>Go Back</a>";
}


?>
</body>
</html>